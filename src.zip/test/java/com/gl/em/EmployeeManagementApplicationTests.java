package com.gl.em;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.gl.em.entity.Role;
import com.gl.em.entity.User;
import com.gl.em.repository.UserRepository;

@SpringBootTest
class EmployeeManagementApplicationTests {
	@Autowired 
	UserRepository userRepository;
	
	@Test
	void contextLoads() {
		User u=new User();	
		Role r=new Role();
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		String encoderValue=encoder.encode("pass");
		u.setPassword(encoderValue);
		System.out.println("Encoder Value: "+encoderValue);
		u.setUsername("manisha");
		r.setName("ADMIN");
		List<Role> lr=new ArrayList<>();
		lr.add(r);
		u.setRoles(lr);
		userRepository.save(u);
	}

}
