package com.gl.em.serviceImpl;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.em.entity.Role;

public interface RoleRepository extends JpaRepository<Role,Integer>{

}
